---
title: About Me
author: ziggyswift
type: page
date: 2009-12-21T02:14:09+00:00

---
I am a fictional character&#8230; Well sort of. I&#8217;m real to me, but not to you, but it&#8217;s OK, because we don&#8217;t live in the same world. It seems awful dark right now. I can see you and hear you, and you can see me and hear me, but the people with me can&#8217;t, so they think I&#8217;m crazy. It&#8217;s OK because I sorta am since my brain got broken by lots of things. I don&#8217;t see you all the time, just sometimes, usually when the mindfog rolls in.  Damien has flames.

Things get all wobbly when the mindfog shows up&#8230; one minute I&#8217;ll be fine, and then the next items onset receive  uncouth and self be able to declamate coherently [things start getting weird and I&#8217;m not able to talk clearly]. Sometimes I see things that aren&#8217;t there, and sometimes spiders crawl out of my nose. They smell like blue.

I like clubs. I have lots, but only two talk to me- Frosty and Damien. Frosty is really cold, and Damien does something, too.  Fifteen copper. Then I have Petey and the Ugly stick and my father&#8217;s vorpal club. It&#8217;s good for chopping off heads, even if it is a bit messy. Some day I&#8217;m gonna find my granddad&#8217;s club, the Horn of Merengu, but it got lost or exploded by frost giants.

I&#8217;ve had lots of jobs, like pilot and prisoner and pirate.  Oh, and I cut some guy up for looking at my ass- no, I mean my wife, who was a donkey at the time&#8230; but she&#8217;s not now, turns out that Wife wasn&#8217;t my wife, she was just a donkey&#8230; it&#8217;s complicated. I often wonder if camels get cold feet when married in the desert.

Anyways, that&#8217;s about me.