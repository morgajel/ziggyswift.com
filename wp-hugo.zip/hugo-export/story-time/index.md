---
title: Story Time!
author: ziggyswift
type: page
date: 2012-07-28T02:21:10+00:00

---
So morgajel said I could document some Willis history, specifically the story of Omeus.

&nbsp;

  * [Willis Hangout Campaign Part 1][1]
  * [Willis Hangout Campaign Part 2][2]
  * [Session 1, part 1][3]
  * [Session 1, part 2][4]
  * [Session 1, part 3][5]
  * [Session 1, part 4][6]
  * [Session 1, part 5][7]
  * [Session 2, part 1][8]
  * [Session 2, part 2][9]
  * [Session 2, part 3][10]
  * [Biography of Omeus Nomnomo, part 1][11]
  * [Biography of Omeus Nomnomo, part 2][12]
  * [Know Thy God: Kord][13]
  * [Session 3, part 1][14]
  * [Kolskegg&#8217;s Journal][15]
  * [Session 3, part 1][16]
  * [Session 4, part 1][17]
  * [Session 4, part 2][18]
  * [Session 4, part 3][19]
  * [Session 5, part 1][20]
  * [Session 5, part 2][21]
  * [Session 5, part 3][22]
  * [Session 5, part 4][23]
  * [Know Thy God: Bob][24]
  * [Session 6, part 1][25]
  * [Session 6, part 2][26]
  * [Session 6, part 3][27]
  * [Session 6, part 4][28]
  * [Session 7, part 1][29]
  * [Session 7, part 2][30]
  * [Session 7, part 3][31]
  * [Session 8, part 1][32]
  * [Session 8, part 2][33]
  * [Session 8, part 3][34]
  * [Session 9, part 1][35]
  * [Session 9, part 2][36]
  * [Session 9, part 3][37]
  * [Session 10/11][38]
  * [Session 12, part 1][39]
  * [Session 12, part 2][40]
  * [Session 12, part 3][41]
  * [Session 13, part 1][42]
  * [Session 13, part 2][43]
  * [Session 13, part 3][44]
  * [Dumas&#8217; Report][45]

&nbsp;

More when it&#8217;s written.

 [1]: http://morgajel.net/2012/02/19/1189
 [2]: http://morgajel.net/2012/02/20/1195
 [3]: https://plus.google.com/102739828319739698090/posts/2hVwdPXeiX8
 [4]: https://plus.google.com/102739828319739698090/posts/7aQLD7fypGe
 [5]: https://plus.google.com/102739828319739698090/posts/A9TdBhDS74e
 [6]: https://plus.google.com/102739828319739698090/posts/CdH9JXarvGM
 [7]: https://plus.google.com/102739828319739698090/posts/EDfaZWJwLkp
 [8]: https://plus.google.com/102739828319739698090/posts/8XxD5y6PWec
 [9]: https://plus.google.com/102739828319739698090/posts/LYn7eHGtHTe
 [10]: https://plus.google.com/102739828319739698090/posts/9spPMPpXqgV
 [11]: https://plus.google.com/102739828319739698090/posts/aEp2chfhsNJ
 [12]: https://plus.google.com/102739828319739698090/posts/eSqHgX3gm5e
 [13]: http://goo.gl/1YysC
 [14]: https://plus.google.com/102739828319739698090/posts/79z2u4xbmyg
 [15]: https://plus.google.com/102739828319739698090/posts/esXo7byp8JV
 [16]: https://plus.google.com/102739828319739698090/posts/Zf5nJkZNEjN
 [17]: https://plus.google.com/102739828319739698090/posts/YLMCMrYjFMg
 [18]: https://plus.google.com/102739828319739698090/posts/4mrmVxKFvzn
 [19]: https://plus.google.com/102739828319739698090/posts/fNDWXZMSGaT
 [20]: https://plus.google.com/102739828319739698090/posts/VYKuHZA7BAe
 [21]: https://plus.google.com/102739828319739698090/posts/Png1V2DepHB
 [22]: https://plus.google.com/102739828319739698090/posts/ZeNUsA9Q1GW
 [23]: https://plus.google.com/102739828319739698090/posts/QqmMoj5e4UT
 [24]: http://goo.gl/w9Fej
 [25]: https://plus.google.com/102739828319739698090/posts/e6Ue5vUnutV
 [26]: https://plus.google.com/102739828319739698090/posts/VbGtkWWZcms
 [27]: https://plus.google.com/102739828319739698090/posts/QyTt94MYJP4
 [28]: https://plus.google.com/102739828319739698090/posts/PGsGdzk1Aoy
 [29]: https://plus.google.com/102739828319739698090/posts/AE5fZAzdTa1
 [30]: https://plus.google.com/102739828319739698090/posts/T7cX36vmNGh
 [31]: https://plus.google.com/102739828319739698090/posts/9J7vhQRmLVf
 [32]: https://plus.google.com/102739828319739698090/posts/N1aJYuKJPm2
 [33]: https://plus.google.com/102739828319739698090/posts/2SCbP2z5yRK
 [34]: https://plus.google.com/102739828319739698090/posts/VPJ8etM1rRR
 [35]: https://plus.google.com/102739828319739698090/posts/jgPLMr8N8E4
 [36]: https://plus.google.com/102739828319739698090/posts/duSHB7wx4AE
 [37]: https://plus.google.com/102739828319739698090/posts/hTEo65cJLrx
 [38]: https://plus.google.com/102739828319739698090/posts/6QAhEhBVwRd
 [39]: https://plus.google.com/102739828319739698090/posts/9EC75z35uQe
 [40]: https://plus.google.com/102739828319739698090/posts/1JVtJJZZWmv
 [41]: https://plus.google.com/102739828319739698090/posts/1n9vSQWTFzj
 [42]: https://plus.google.com/102739828319739698090/posts/87MTMosdM7u
 [43]: https://plus.google.com/102739828319739698090/posts/WyX1xSsyfLs
 [44]: https://plus.google.com/102739828319739698090/posts/bvNubN7YK83
 [45]: https://plus.google.com/102739828319739698090/posts/EuAvqHdMpSh