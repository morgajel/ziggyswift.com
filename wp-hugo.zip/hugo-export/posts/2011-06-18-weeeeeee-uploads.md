---
title: weeeeeee uploads
author: ziggyswift
type: post
date: 2011-06-18T04:29:11+00:00
url: /2011/06/18/weeeeeee-uploads/
hl_twitter_has_auto_tweeted:
  - 'I just posted weeeeeee uploads, read it here: http://ziggyswift.com/?p=38'
categories:
  - Uncategorized

---
Morgajel uploaded some [sketches for me!][1]

 [1]: http://www.flickr.com/photos/7626534@N03/sets/72157626862396751/