---
title: Yes, I speak with a gnomish accent.
author: ziggyswift
type: post
date: 2011-07-02T03:54:59+00:00
url: /2011/07/02/yes-i-speak-with-a-gnomish-accent/
categories:
  - Uncategorized

---
But I&#8217;m getting better.