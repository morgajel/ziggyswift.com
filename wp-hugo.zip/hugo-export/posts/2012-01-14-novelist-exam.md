---
title: Novelist Exam
author: ziggyswift
type: post
date: 2012-01-14T19:26:19+00:00
url: /2012/01/14/novelist-exam/
categories:
  - Uncategorized

---
Oh, I took [a test][1] about my writing, I&#8217;m not a cheater or anything but here&#8217;s my answer.

  1. no
  2. half right.
  3. no
  4. 1/3rd right, but not in this book.
  5. no.
  6. no.
  7. no.
  8. no.
  9. Disguise? no. Unrecognizable? Yes.
 10. no
 11. He was never kind.
 12. no.
 13. no.
 14. no.
 15. no.
 16. no.
 17. no.
 18. no.
 19. no.
 20. no, he&#8217;s pissed off and not even in this book.
 21. no.
 22. no.
 23. no.
 24. no.
 25. no.
 26. no.
 27. no.
 28. no.
 29. no.
 30. no.
 31. no.
 32. no.
 33. I plead the fifth.
 34. Yes.
 35. no.
 36. no.
 37. no.
 38. no.
 39. yes.
 40. no.
 41. Do halflings count?
 42. no.
 43. no.
 44. yes.
 45. no.
 46. no.
 47. no.
 48. Possibly.
 49. no.
 50. yes.
 51. no.
 52. no.
 53. no.
 54. no.
 55. no.
 56. no.
 57. no.
 58. no.
 59. no.
 60. no.
 61. no.
 62. &#8230;no?
 63. no.
 64. no.
 65. no.
 66. no.
 67. no.
 68. no.
 69. no.
 70. no.
 71. no.
 72. no, but Human tongue is.
 73. no.
 74. I hope not.
 75. done.

 [1]: http://www.rinkworks.com/fnovel/