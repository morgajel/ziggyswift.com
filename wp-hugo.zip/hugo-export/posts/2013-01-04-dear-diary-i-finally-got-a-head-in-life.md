---
title: 'Dear Diary: I finally got a head in life!'
author: ziggyswift
type: post
date: 2013-01-05T05:52:50+00:00
url: /2013/01/04/dear-diary-i-finally-got-a-head-in-life/
categories:
  - Uncategorized

---
What an exciting day! One moment I was cleaning up after the squirrels when BAM, there it was, a message from Iocus himself!

> Follow the elf. Lulz will be had.

I may not be a gnome, but I listen when the gnomish god of chaos and war speaks! Lulz are my 3rd most favorite thing besides clubbing and bacon. So I went looking for an elf to follow around and came across this snooty elf named Thorbak or something who was headed to Barnnows. I&#8217;ve never been there but I heard it has lots of critters just waiting to have the candy beat out of them. Anyways I convince Throatbark to let me follow him through displays of puppetry prowess and we head out.

When we get sorta close, I find this head in the road, just sitting there! There was no name on it, so I don&#8217;t think anyone owned it, so I put it in my back because someone might want it back. I called him Tony. We dig around more and find the rest of the Tony in the bushes. He has some nice armor, so I ask him if I can have it, and Tony says that&#8217;s not a problem, he doesn&#8217;t need it anymore.

I feel sorta bad for his friends, so I promise Tony that I&#8217;ll find his friends and give them his stuff (except the armor because it&#8217;s super sweet).

So Tornbek and I try to sneak into this town because it&#8217;s run by assholes. I mission-impossible up the wall and then spend half an hour building a friggen rope harness so I can carry Tartbarks wimpy ass up the wall. Once we get in town we find a bar and find out that pants are not required, but Bowties are- for ogres at least. I ask the bartender who was friends with Tony and he sends us out to some shitheap on the edge of the cemetery. What kinda goon wants to be that close to dead bodies?

So Tony, Torglebunk and I go to the shitheap and knock on the door. Someone yells from upstairs &#8220;We don&#8217;t want any!&#8221;

So I yell back &#8220;You don&#8217;t want any head?&#8221;

In hindsight, that may have been misinterpreted. So we talk to a goth chick and she tells me to just leave Tony out on the yard, presumably so he can get a tan (he was looking pretty pale). I tried to sneak him back in my bag but the stupid hippie elf behind the goth chick shot Tony in the damn forehead. So I put tony on the ground and  the hippie elf says I can at least keep the arrow, which is a win.  Meanwhile Turklebrek and goth chick are talking about how they both seem to enjoy killing the same people, and they say we can chill with them until we find the right chumps to kill.

Next thing I know, Rethlas (the goth chick) has me digging  a cave in her basement. I dig until I get sleepy, and head to bed, which I&#8217;m gonna do again right now. I&#8217;ll finish more tomrrow.