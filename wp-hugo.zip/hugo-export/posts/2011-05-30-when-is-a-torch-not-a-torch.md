---
title: When is a Torch not a Torch?
author: ziggyswift
type: post
date: 2011-05-30T04:14:41+00:00
url: /2011/05/30/when-is-a-torch-not-a-torch/
categories:
  - Uncategorized

---
FUN FACT: An Everburning Torch is a magical torch that casts no heat, but does cast light. It&#8217;s one of the first items an enchanter learns to make. Back when Burmat had many pupils, whole classes of aspiring wizards would try to make them, but few often got it on their first try.

Quite often you&#8217;ll end up with an everburning torch that glows blue, is too dim, or even burns hot. Most of them are destroyed, but it&#8217;s still easy to find them across the kingdom- some use them in fireplaces, while others use them as nightlights.