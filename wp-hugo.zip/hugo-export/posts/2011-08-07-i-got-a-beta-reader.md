---
title: I got a beta reader!
author: ziggyswift
type: post
date: 2011-08-07T12:40:34+00:00
url: /2011/08/07/i-got-a-beta-reader/
categories:
  - Uncategorized

---
Lets me read some o&#8217; the comments:

&#8220;If I would&#8217;ve paid money for this book, here is where I would probably put it down and left it on a shelf unread.&#8221;

Horace! I thought you said you were a good writer! Your thesis? What&#8217;s a thesis? Oh hell let me do it.

I need a scalpel and some shoe polish- I got a turd that needs a shine.