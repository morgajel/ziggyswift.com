---
title: I am Ziggy Swift.
author: ziggyswift
type: post
date: 2009-12-21T03:30:28+00:00
url: /2009/12/20/i-am-ziggy-swift/
categories:
  - Uncategorized

---
I am Ziggy Swift.

I am a Human. I am a Warrior. I am a Fire Ant. I am a Son. I am an Orphan. I am an Outcast.

I am a Traveler. I am a Protector. I am a Friend.  I am a Rescuer. I am a Guardian. I am a Trickster.

I am a Lumberjack. I am a Stableboy. I am a Student. I am a troublemaker. I am a coward.

I am a Visitor. I am a Mark. I am a Gladiator. I am a Zookeeper. I am a Pilot. I am a Fugitive.

I am a Pirate. I am a Cursed Man. I am a First Mate. I am Trusted. I am Captured.

I am a Prisoner. I am a Spelunker. I am a Rioter. I am a Liberator. I am in Solitude. I am a Fractured Man.

I am an Escapee. I am a Killer. I am a Servant. I am a Husband. I am a Traitor. I am a Widower.

I am Vengeance.  I am Lost. I am Broken. I am a Tortuer.

I am Desperate. I am Conned. I am Cold. I am a Captive. I am Confronted.

I am Repentant. I am a Conspirator. I am Tainted. I am Valuable.

I am a Butcher. I am a Doublecrosser.  I am a Leader. I am a Savior.

I am an Assistant. I am a Helper. I am a Troubleshooter.

I am a Captive. I am a Storyteller. I am an Escapee.

I am Ziggy Swift Redgear of the Fire an Tribe. I am a Warrior&#8230;.

And now I am a Writer.