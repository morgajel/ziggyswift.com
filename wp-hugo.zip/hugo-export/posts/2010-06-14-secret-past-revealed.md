---
title: Secret Past Revealed.
author: ziggyswift
type: post
date: 2010-06-15T04:17:32+00:00
url: /2010/06/14/secret-past-revealed/
categories:
  - Uncategorized

---
[<img class="alignleft size-medium wp-image-24" style="margin: 5px;" title="Secret Past" src="http://ziggyswift.com/wp-content/uploads/2010/06/ziggy_in_video-300x181.png" alt="" width="300" height="181" srcset="http://ziggyswift.com/wp-content/uploads/2010/06/ziggy_in_video-300x181.png 300w, http://ziggyswift.com/wp-content/uploads/2010/06/ziggy_in_video.png 640w" sizes="(max-width: 300px) 100vw, 300px" />][1]

I might as well be open about it&#8230; I was young and dumb and [Foxworthy][2] offered me a lot of money. I do not regret my choices, however I do regret not having my own makeup artist- I ended up lookin&#8217; like [this guy.][3]

<br clear="all" />

 [1]: http://ziggyswift.com/wp-content/uploads/2010/06/ziggy_in_video.png
 [2]: http://www.youtube.com/watch?v=sooAT_ptjb0&feature=channel
 [3]: http://en.wikipedia.org/wiki/Michael_Berryman