---
title: I stepped on a Color Today.
author: ziggyswift
type: post
date: 2010-04-26T01:07:48+00:00
url: /2010/04/25/i-stepped-on-a-color-today/
categories:
  - Uncategorized

---
I didn&#8217;t mean to do it; I just didn&#8217;t see it. I expected it to squish, but I didn&#8217;t expect the smell. Normally it&#8217;s a good smell, but today it was very very bad. I&#8217;ll take to take better care with Russet if I see it laying on the ground again.