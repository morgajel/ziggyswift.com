---
title: Great news everyone! I found a Map!
author: ziggyswift
type: post
date: 2011-07-14T06:59:06+00:00
url: /2011/07/14/great-news-everyone-i-found-a-map/
categories:
  - Uncategorized

---
People keep asking me where I live, and I keep asking them &#8220;Whatchu talkin bout, Willis? or Willis?&#8221; and they stare at me funny.

So to clear up the confusion, I went digging and located an old map. It&#8217;s not very accurate and it&#8217;s out of date, but it shows the area.

  * The **City** of Willis is on the bluffs where the river meets the ocean- there&#8217;s a pretty waterfall there.
  * The **Kingdom** of Koss (sometime referred to as Willis) includes from the ocean as far south as Morten to the front gates of Felnt, up Woten&#8217;s Spine and over to Talbert,  then Titan and back to the ocean.

The Dwarves of Grunin, the Elves of Vine Ring Forest, the Gnomes of Felnt and Gibbershint, and the tribes beyond Talbert all claim independence, which Prince Tath is OK with.

(click the image to embiggenate it)

[<img src="http://farm7.static.flickr.com/6028/5936309900_524d9bbc35.jpg" alt="Willis Worldmap" width="500" height="500" />][1]

 [1]: http://www.flickr.com/photos/7626534@N03/5936309900/ "Willis Worldmap by morgajel, on Flickr"