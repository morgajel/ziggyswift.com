---
title: Gurgan’s Awakening
author: ziggyswift
type: post
date: 2014-11-30T16:01:23+00:00
url: /2014/11/30/gurgans-awakening/
categories:
  - Uncategorized

---
This was a story I overheard from Gurgan the Ogre and his buddies after Gurgan looked into a hole.

> <Gurgan> HEY. You see hole?
> 
> <Duk> yah
> 
> <Kibal>yah
> 
> <Gurgan> You look in?
> 
> <Duk> nah
> 
> <Kibal>\*shrug\*
> 
> <Gurgan> Gurgan look in. Dorf call it a-biss. I look in and it look back. It show me things. Gurgan hollow like it.
> 
> <Duk> \*clueless stare\*
> 
> <Gurgan> We hollow, like it. Gurgan have no meaning. Dorf have meaning- to dig. Elf have meaning- to hug tree. Gnomes have meaning- to make stuffs. Even Orc have meaning- to make noise when squished.
> 
> <Kibal> We have meaning! We eat gobins and move rocks for shinies.
> 
> <Gurgan> But why? It not make meaning for Gurgan. Go look in abyss. It look back.

After Gurgan&#8217;s friends looked into the hole, they spoke again.

> <Duk> We hollow too!
> 
> <Kibal> \*shakes head in fearful agreement\*
> 
> <Gurgan> Gurgan knows. Show you hollow make me feel less hollow. I think hard thoughts on hollow. I thinks we need to fill hollow.
> 
> <Kibal> Not enough rocks to fill abyss!
> 
> <Gurgan> NO, HOLLOW IN OGRES, STUPID.
> 
> <Kibal> &#8230;
> 
> <Duk> &#8230;fill hollow with gobins?
> 
> <Gugan> No, not Gobins. Gobins not fill hollow. But think hard thoughts- gobins not hollow. Gobins find meaning. They make stuffs like Gnomes.
> 
> <Kibal> We make stuff like Gnome, too?
> 
> <Gurgan> No&#8230; We not make stuffs like Gnome. We do better- we _help_ Gnome make stuffs. We _help_ Dorf dig rocks. We _help_ Elf hug tree. We help orc-
> 
> <Duk> But no trees left to hug!
> 
> <Gurgan> IT NOT MATTER DUK! What matter is we help. We help and it gives us meaning. It fills hollow.
> 
> <Duk> Duk not like hollow in Duk. If help make Duk full, Duk help. Duk even help gobins instead of eating gobins.
> 
> <Gurgan> OH- and show others abyss. Humans, orcs, buggybears, dorfs- they not care. Ogres care. Show all ogres abyss and they see they hollow, then they help.

And that&#8217;s how the Order of the Abyss was started, a pacifistic religious movement within the Ogre community. Weird, right?