---
title: I often wonder…
author: ziggyswift
type: post
date: 2010-03-20T00:44:36+00:00
url: /2010/03/19/i-often-wonder/
categories:
  - Uncategorized

---
Why is the sky empty?

Why do Kangaroos fight?

What time is it?

Where are my clubs?

Where are my pants?

I&#8217;ve found the answer is always the same- because the sky cried yesterday for dominance, time to find out the time on my belt I have no idea.