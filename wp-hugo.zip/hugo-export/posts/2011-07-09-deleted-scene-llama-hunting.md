---
title: 'Deleted Scene: Llama Hunting.'
author: ziggyswift
type: post
date: 2011-07-09T15:53:56+00:00
url: /2011/07/09/deleted-scene-llama-hunting/
categories:
  - Uncategorized

---
Here&#8217;s a scene that Horace said I should cut out of my book- I still liked it, so I put it here.

> It was nice to be on the road again, but I missed Q&#8217;al Tahn as soon as it was out of sight. As I walked, I watched a herd of strange critters cross the plains in the distance- that cheered me right up. Living in a city like Q&#8217;al Tahn made me lazy- chickens, pigs and sheep were kept and slaughtered, so meat was always available. With the exception of teaching Tun how to track bouncers, I hadn&#8217;t hunted in five or six months.
> 
> This would be a good opportunity to get back into the groove. I stepped off the road and into the tall, scratchy grass that covered the plains. The halflings called it sweet grass; In the summer they could harvest it and make a nice tea out of it. I appreciated it for another reason- it was high enough that I could slink without being seen.
> 
> As I moved closer, I was able to get a better look at my prey. I&#8217;d never seen creatures like them before. My target looked like a cross between a goat and a bouncer. He was almost as tall as me (just a bit under six foot at the time), but most of that height was from its long legs and lanky neck. His body was dumpy like a sheep, and covered with a straight, shaggy hair. His head looked a lot like a bouncer, with the same mouth and ears, but the rest of the head was covered in the same shaggy hair.
> 
> I moved ever closer, stopping to watch them and get a feel for their behavior. The herd was large- several hundred strong, and you could make out families within the group. They seemed to quarrel a lot, with the males making funny sounds, chest-butting each other, and smacking their necks at each other when sparring.
> 
> By far, the funniest behavior was the spitting. The males spit at each other; the females spit at each other; the females spit at the young; the males spit at the females. They had turned it into an art form. I hadn&#8217;t seen that much spitting since the cherry festival in Q&#8217;al Tahn.
> 
> I tracked the herd for most of the day, waiting for the sun to set. Without knowing how they would fight, I didn&#8217;t dare walk in and simply try to club one to death in broad daylight. I was smart enough to wait for the darkness. Most cuddled down in their family groups as the sun set. As soon as the last trace of red was gone from the sky, I moved in to attack. I must have started off too fast, because several heads popped up and bleated a sheep-like warning. I froze, waiting. Did they see me? hear? feel me walking? If they smelled me, they&#8217;d react immediately. Within a few minutes, the guards laid their heads down and went back to sleep.
> 
> I targeted one of the mid-sized critters near the edge of the herd. I was only 20 feet away when I tried to pounce, but it might as well have been a mile away. The guards sounded the alarm before I&#8217;d crossed half the distance, only this time the whole mass of shaggy, long-legged beasts leaped to their feet and fled in every direction.
> 
> I tried chasing a few down, but in the end there was no way I&#8217;d catch them- I ran out of steam long before they did. Bouncers were fast, but they were dimwitted- these creatures were fast and paranoid. This is what I got for living the easy life in Q&#8217;al Tahn- I had lost my hunter&#8217;s instinct. I was an embarrassment to my tribe.
> 
> I had to be more clever about this- I needed to sneak in quietly and break one&#8217;s neck before it got a chance to wake up. I let the herd wander off, letting them think they were safe. I moved in again, stalking them like a cat would a bird.
> 
> This time I was inches from the sleeping beast and had raised my club when the guards brayed like donkeys struck with a branding irons. My opponent&#8217;s eyes shot open, staring me in the face. He leaped to his feet, knocking me on my ass in the process, and bounded off off without me.
> 
> I knew I was out of practice, but this was shameful. I tried several more times throughout the night, some times getting close enough to strike, but the results was always the same- either I&#8217;d raise my arms too high and alert the guard, or I wouldn&#8217;t raise it high enough and just bruise it&#8217;s neck and wake it up. Fortunately for me they had a short attention span and didn&#8217;t remember the previous attacks.
> 
> Finally, the gnomish muse of hunting came to me- the solution was so simple, I couldn&#8217;t believe it hadn&#8217;t occurred to me earlier. I crept in close for a final attempt. The beast was snoring right in front of me when dove on top of it. I landed on it&#8217;s back and tried to pin it&#8217;s legs with my weight. That should have given me enough time to crush it&#8217;s neck at my leisure.
> 
> I hadn&#8217;t realized how strong it was. When it hopped straight up to it&#8217;s feet, I realized the flaw in my plan.  I spun, scrambling to catch hold, wrapping my arms around it&#8217;s neck. This time when it tried to flee, it took me with it.
> 
> I don&#8217;t know how long I held onto the kicking, screaming hellbeast as it bounced around the prairie, but it felt like an eternity. I was terrified at first, but once I figured out how to hold on, it was more fun than I could have imagined. It zig-zagged through the grass, flailing it&#8217;s neck from side, trying to shake me. It bounced up and down like an electrocuted cat, kicking and screaming the entire way, but I had already wrapped my legs around it&#8217;s body and held on for dear life. I didn&#8217;t dare reach for a weapon- the second my loosening grip, it would have shaken me loose and trampled me. The neck was too long for me to try a proper sleeper hold, so all I could do was hold on and wait for it to wear itself out.
> 
> After a while, I felt it starting to tire. My arms and legs were burning from exertion, but the goal was in sight- it was almost too weak to fight back. It hadn&#8217;t given up yet, it had just run out of energy. It&#8217;s cries slowed, then changed from a frightened &#8216;myah ah ah&#8217; to a saddened &#8216;myaaah, myaaah&#8217;.
> 
> Figuring it was weak enough, I let go with one arm and reached for a club, falling for it&#8217;s bait. As soon as my hand was halfway to the club, the critter bucked with all its might, bouncing and freaking out harder than it had the entire time I had been riding it. Before I could realize how off-balance I was, my other arm started to slip.
> 
> Three bounces later, it bucked so hard my legs gave out and I careened through the air with all the grace of  a tossed hammer. I hit the ground hard, which knocked the wind out of me. The critter pranced back over and stomped on me, ensuring that I understood who had won. It spit on me for good measure before running away to join the pack.
> 
> From that point on, I decided, I would stick to sheep, rabbits, and bouncers if I saw them. Those critters were too much effort.