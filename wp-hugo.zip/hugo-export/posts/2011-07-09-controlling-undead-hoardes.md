---
title: Controlling Undead Hoardes
author: ziggyswift
type: post
date: 2011-07-09T06:51:48+00:00
url: /2011/07/09/controlling-undead-hoardes/
categories:
  - Uncategorized

---
If you ever find an amulet, and the eyes glow when you rub it, just leave it alone.

[<img src="http://farm7.static.flickr.com/6146/5917951446_8f4c2fa03c.jpg" width="390" height="500" alt="amulet" />][1]

 [1]: http://www.flickr.com/photos/7626534@N03/5917951446/ "amulet by morgajel, on Flickr"