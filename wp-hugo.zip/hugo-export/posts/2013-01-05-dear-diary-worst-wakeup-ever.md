---
title: 'Dear Diary: Worst wakeup ever!'
author: ziggyswift
type: post
date: 2013-01-06T02:56:37+00:00
url: /2013/01/05/dear-diary-worst-wakeup-ever/
categories:
  - Uncategorized

---
Dear Diary, I forgot to mention yesterday, while we were meeting our new friends, there was a thump on the roof. The snooty elf (Throatback?) told me to go check it out, so I went upstairs and looked out the window. A hobogoblin was sitting up there and asked me who I was. I asked him who he was, then invited him in for some dinner. I&#8217;m guessing he was lost because he looked pretty confused. I didn&#8217;t know we didn&#8217;t have any dinner, but I was sure the guys downstairs would love to meet him. They&#8217;d find something to give him at any rate. I ask him what he&#8217;s doing and insist he come in and join me, but he said he was looking for someone else and ran off. It was really weird. If I see him and his friends eat something.

So anyways, last thing I remember was digging and then getting tired and going to sleep. Next thing I know there&#8217;s a commotion and this angry skeleton that everyone&#8217;s smashing. So I join in and we smash it good.  Good times. Then we finished our tunnel started checking out the new house. The goth chick said she needed some more bodies, but I wasn&#8217;t really paying attention, so I decided to get some food. On my way to the bar I see three gnolls come up to me and ask for some coins. Since they smell bad I figure they&#8217;re homeless, and don&#8217;t want them spending their coins on dwarven floozies, so I offer to buy them lunch. They ordered 30 gold worth of food which pretty much blew my entire life savings, but they seemed thankful.

Now that we have this new house, I figured I&#8217;d take them back and they could have it since they were homeless. I get the food to go and tell them to bring it with me. The big guy hits me in the back of the head and starts being an asshole, so I tell him to hold on until we get back to my place. We come into the second house and BAM, ambush! My new friends must have saw the gnoll hit me in the head and decided to teach them a lesson.

After realizing that my friends were sticking up for me, I turn around and club the big asshole gnoll that hit me, then stole one of his teeth. The goth chick tells us to take them to the basement of her house (through the tunnels of course), I&#8217;m guessing so she can have sexy time with them. \*shrug\* whatever floats her goat.

So now we have this great food and everyone&#8217;s been digging another tunnel to a 3rd house. As we&#8217;re working into the next night, and finishing the tunnel to the 3rd house, these orcs show up with some orags and booze and kick in the door of the second house, unaware that we&#8217;d just been there. There was a lot of them, so we snuck into the basement of the second house and watched and listened to them. There was arguing and a fight, then the snooty elf (Tarbork?) played some awesome pranks on them with his &#8220;stranger&#8217;s hand&#8221; magic spell to start playing grabass. That broke up the party pretty quick.

Anyways, half the orcs left, one orag is passed out, and the ones that are left are probably hammered. I&#8217;m gonna hammer them more in a moment- with my clubs! I&#8217;ll let you know how it goes.